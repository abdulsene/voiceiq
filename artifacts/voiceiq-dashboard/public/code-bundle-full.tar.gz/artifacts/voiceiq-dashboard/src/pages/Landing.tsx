import { useState } from "react";
import { Link } from "wouter";
import LandingNav from "../components/LandingNav";
import LandingFooter from "../components/LandingFooter";
import NeverrVoiceWidget from "../components/NeverrVoiceWidget";
import EarlyAccessSection from "../components/EarlyAccessSection";
import {
  Sparkles, ArrowRight, Check, Clock, Zap,
  Briefcase, Heart, Wrench, Scale,
} from "lucide-react";

// Hero industry switcher conversation scripts
const HERO_CONVERSATIONS: Record<string, {
  label: string;
  icon: any;
  caller: string;
  badges: { label: string; subtitle: string }[];
  messages: { from: "caller" | "ai"; text: string }[];
  handoff: string;
}> = {
  plumbing: {
    label: "Plumbing",
    icon: Wrench,
    caller: "+1 (415) ••• 0918",
    badges: [
      { label: "BOOKED", subtitle: "Tech dispatched · ETA 38 min · $0 booking fee" },
    ],
    messages: [
      { from: "caller", text: "Hey — I've got water coming up through the kitchen floor. Are you guys 24-hour?" },
      { from: "ai", text: "Yes — we dispatch 24/7. I'll get a tech to you tonight. Have you shut the main valve under the sink?" },
      { from: "caller", text: "Just did. Water slowed down a lot." },
    ],
    handoff: "Synced to ServiceTitan + texted owner",
  },
  dental: {
    label: "Dental",
    icon: Heart,
    caller: "+1 (212) ••• 4471",
    badges: [
      { label: "BOOKED", subtitle: "Cleaning + exam · Wed 2:30pm · Insurance verified" },
    ],
    messages: [
      { from: "caller", text: "I haven't been in a few years and my tooth started hurting last night." },
      { from: "ai", text: "Sorry to hear that. Let me get you in for an exam — do you have insurance, and which side is the pain?" },
      { from: "caller", text: "Delta Dental. Bottom right, sharp when I drink anything cold." },
    ],
    handoff: "Logged in Dentrix + emergency flag set",
  },
  legal: {
    label: "Legal",
    icon: Scale,
    caller: "+1 (305) ••• 8821",
    badges: [
      { label: "INTAKE", subtitle: "Consult booked · Friday 10am · No fee until won" },
    ],
    messages: [
      { from: "caller", text: "I was rear-ended yesterday. The other driver's insurance keeps calling me." },
      { from: "ai", text: "Don't give them a recorded statement until we talk. Are you injured? I can get you in with an attorney this week." },
      { from: "caller", text: "Neck and back are bad. Going to urgent care today." },
    ],
    handoff: "Synced to Clio + paralegal alerted",
  },
  hvac: {
    label: "HVAC",
    icon: Zap,
    caller: "+1 (713) ••• 0044",
    badges: [
      { label: "BOOKED", subtitle: "Diagnostic visit · Tomorrow 9am · $89 service call" },
    ],
    messages: [
      { from: "caller", text: "AC stopped working last night. The thermostat says it's cooling but no air comes out." },
      { from: "ai", text: "Sounds like the blower or capacitor. We can have someone there tomorrow morning. Is the unit indoors or outside?" },
      { from: "caller", text: "Outside, in the side yard. It's still buzzing but no fan." },
    ],
    handoff: "Job created + parts truck pre-loaded",
  },
};

// Industry showcase tiles (10 visible)
const INDUSTRY_TILES = [
  { label: "Plumbing", industry: "plumbing" },
  { label: "Dental", industry: "dental_office" },
  { label: "Law firms", industry: "law_firm" },
  { label: "HVAC", industry: "hvac" },
  { label: "Med spa", industry: "med_spa" },
  { label: "Veterinary", industry: "veterinary_clinic" },
  { label: "Real estate", industry: "real_estate" },
  { label: "Auto repair", industry: "auto_repair_shop" },
  { label: "Auto detailing", industry: "auto_detailing" },
  { label: "Home health", industry: "home_health" },
];

// 3 sample call snippets for the dark slab section (replaces testimonials)
const SAMPLE_CALLS = [
  {
    industry: "Plumbing · Emergency intake",
    caller: "\"My water heater is leaking everywhere — what do I do right now?\"",
    response: "Step-by-step: shut off the cold water inlet (handle on top), then the gas/breaker. I'm dispatching a tech for emergency rate. ETA in your area is 35 minutes. Stay out of standing water near the unit.",
  },
  {
    industry: "Dental · After-hours booking",
    caller: "\"It's 9pm and my front tooth chipped. Can someone see me tomorrow?\"",
    response: "We have a 7am emergency slot tomorrow with our on-call dentist. I'm holding it for you. Bring the chip if you can find it — sometimes we can re-bond. Need your insurance to verify coverage tonight?",
  },
  {
    industry: "Legal · Personal injury triage",
    caller: "\"Insurance is asking me to sign something. Should I?\"",
    response: "Don't sign anything yet. That release usually waives your right to future treatment claims. I'm booking you with a senior attorney this Friday at 10am — no fee unless we win. What's the best email for the file?",
  },
];

export default function Landing() {
  const [activeIndustry, setActiveIndustry] = useState<string>("plumbing");
  const conversation = HERO_CONVERSATIONS[activeIndustry];

  return (
    <div className="min-h-screen bg-[#FAFAF7] text-slate-900">
      <LandingNav />

      {/* ───────────────── HERO ───────────────── */}
      <section className="px-6 pt-12 pb-20 md:pt-20 md:pb-28">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left: Headline + CTAs */}
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-mono mb-6">
              <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-pulse"></span>
              v4.2 · 193+ industry playbooks live
            </div>

            <h1 className="text-5xl md:text-6xl font-bold tracking-tight leading-[1.05] mb-6">
              Never miss a call.
              <br />
              Never sound{" "}
              <span className="bg-gradient-to-r from-indigo-600 to-violet-500 bg-clip-text text-transparent">
                generic
              </span>
              .
            </h1>

            <p className="text-lg text-slate-600 mb-8 max-w-lg leading-relaxed">
              An AI receptionist trained for <strong className="text-slate-900">your</strong> industry — 193+ specialties calibrated for the exact conversations your customers actually have.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 mb-4">
              <Link
                href="/try-your-agent"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800 transition-colors shadow-md"
              >
                Try live demo <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/signup"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-white border border-slate-300 text-slate-900 rounded-lg font-semibold hover:bg-slate-50 transition-colors"
              >
                Start free trial
              </Link>
            </div>
            <p className="text-xs text-slate-500 font-mono">7-day free trial · cancel anytime</p>
          </div>

          {/* Right: Phone visual with industry switcher */}
          <div className="relative">
            {/* Industry switcher tabs */}
            <div className="flex items-center gap-1 mb-3 p-1 bg-slate-100 rounded-lg w-fit">
              {Object.entries(HERO_CONVERSATIONS).map(([key, conv]) => {
                const Icon = conv.icon;
                return (
                  <button
                    key={key}
                    onClick={() => setActiveIndustry(key)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                      activeIndustry === key
                        ? "bg-white text-slate-900 shadow-sm"
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    <Icon className="w-3 h-3" />
                    {conv.label}
                  </button>
                );
              })}
            </div>

            {/* Phone transcript card */}
            <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
              {/* Header bar */}
              <div className="px-5 py-3 border-b border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-mono">incoming · {conversation.caller}</span>
                <span className="flex items-center gap-1.5 text-emerald-600 font-medium">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                  live · 00:42
                </span>
              </div>

              {/* Booking badge */}
              {conversation.badges.map((badge, i) => (
                <div key={i} className="mx-5 mt-4 px-3 py-2 bg-slate-900 text-white rounded-lg text-xs">
                  <div className="font-semibold">{badge.label}</div>
                  <div className="text-slate-300 text-[11px] mt-0.5">{badge.subtitle}</div>
                </div>
              ))}

              {/* Messages */}
              <div className="px-5 py-4 space-y-3">
                {conversation.messages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.from === "ai" ? "justify-end" : "justify-start"}`}>
                    {msg.from === "caller" && (
                      <div className="w-7 h-7 rounded-full bg-slate-200 flex-shrink-0 mr-2"></div>
                    )}
                    <div className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm ${
                      msg.from === "ai"
                        ? "bg-indigo-100 text-slate-900 rounded-br-sm"
                        : "bg-slate-100 text-slate-900 rounded-bl-sm"
                    }`}>
                      {msg.text}
                    </div>
                    {msg.from === "ai" && (
                      <div className="w-7 h-7 rounded-full bg-indigo-500 text-white text-xs font-bold flex items-center justify-center flex-shrink-0 ml-2">
                        AI
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Footer waveform + handoff */}
              <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-end gap-0.5 h-6">
                  {[0.3, 0.7, 0.5, 0.9, 0.4, 0.8, 0.6, 0.3, 0.7, 0.5, 0.9, 0.4].map((h, i) => (
                    <div
                      key={i}
                      className="w-0.5 bg-indigo-400 rounded-full"
                      style={{ height: `${h * 100}%`, animation: `pulse 1.5s ease-in-out ${i * 0.1}s infinite` }}
                    />
                  ))}
                </div>
                <span className="text-[10px] text-slate-500 font-mono">listen to call →</span>
              </div>

              {/* Handoff badge */}
              <div className="mx-5 mb-4 px-3 py-2 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800">
                <span className="font-semibold uppercase tracking-wide text-[10px]">Handoff</span>
                <div className="mt-0.5">{conversation.handoff}</div>
              </div>
            </div>
          </div>
        </div>
        <div data-hero-sentinel aria-hidden="true" />
      </section>

      {/* ───────────────── BRAND PROMISE STRIP ───────────────── */}
      <section className="bg-gradient-to-r from-slate-900 via-indigo-900 to-slate-900 py-10 md:py-12 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-2xl md:text-4xl font-bold tracking-tight leading-tight">
            <span className="text-white">Never miss a call.</span>
            {" "}
            <span className="text-white/70">Never miss a client.</span>
            {" "}
            <span className="bg-gradient-to-r from-indigo-300 via-violet-300 to-indigo-300 bg-clip-text text-transparent">
              Neverr.
            </span>
          </p>
          <p className="text-xs md:text-sm font-mono text-indigo-300 mt-4 tracking-wider uppercase">
            Never miss another dollar.
          </p>
        </div>
      </section>

      {/* ───────────────── TRUST STRIP ───────────────── */}
      <section className="border-y border-slate-200 bg-white py-4">
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-center">
          <p className="text-[11px] font-mono text-slate-400 tracking-wider">
            193+ INDUSTRIES ·{" "}
            <Link href="/multilingual" className="hover:text-indigo-600 transition-colors underline-offset-2 hover:underline">
              32 LANGUAGES
            </Link>
            {" "}· 24/7 ALWAYS
          </p>
        </div>
      </section>

      {/* ───────────────── THREE-UP FEATURES ───────────────── */}
      <section id="features" className="px-6 py-20">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12">
            <p className="text-xs font-mono text-indigo-600 mb-2">// WHAT MAKES NEVERR DIFFERENT</p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight max-w-2xl">
              A receptionist that actually knows your business.
            </h2>
            <p className="text-slate-600 mt-3 max-w-xl">
              Generic voice AI gets things almost right. Neverr is calibrated per-industry — so the first call sounds like the hundredth.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-5">
            {[
              {
                num: "01",
                title: "Industry-calibrated",
                desc: "Not \"an AI receptionist.\" A plumber's receptionist. A dentist's. A personal injury firm's. 193+ playbooks tuned to the questions callers actually ask in your industry.",
              },
              {
                num: "02",
                title: "Never misses a call",
                desc: "24/7, every ring answered in under two seconds. Overflow, after-hours, lunch break — Neverr is on. Callbacks scheduled when a human is needed.",
              },
              {
                num: "03",
                title: "Live demo, no signup",
                desc: "Pick your industry, hit dial, and have a real conversation with the agent that would answer your phones — before you ever enter a credit card.",
              },
            ].map((f) => (
              <div key={f.num} className="bg-white rounded-2xl p-6 border border-slate-200 hover:border-slate-300 transition-colors">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-10 h-10 bg-indigo-50 rounded-lg flex items-center justify-center">
                    {f.num === "01" && <Briefcase className="w-5 h-5 text-indigo-600" />}
                    {f.num === "02" && <Clock className="w-5 h-5 text-indigo-600" />}
                    {f.num === "03" && <Sparkles className="w-5 h-5 text-indigo-600" />}
                  </div>
                  <span className="text-xs font-mono text-slate-400">{f.num}</span>
                </div>
                <h3 className="text-lg font-bold mb-2">{f.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ───────────────── INDUSTRY SHOWCASE ───────────────── */}
      <section className="px-6 py-20 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-xs font-mono text-indigo-600 mb-2">// 193+ PLAYBOOKS</p>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
                Calibrated for the call your customer is about to make.
              </h2>
            </div>
            <Link href="/industries" className="hidden md:flex items-center gap-1 text-sm font-medium text-slate-600 hover:text-slate-900 flex-shrink-0">
              Browse all 193+ industries <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {INDUSTRY_TILES.map((tile) => (
              <Link
                key={tile.label}
                href={`/try-your-agent?industry=${tile.industry}`}
                className="bg-slate-50 hover:bg-slate-100 transition-colors rounded-xl p-5 text-center group"
              >
                <div className="text-xs font-mono text-slate-400 mb-1">[ {tile.label.toUpperCase()} ]</div>
                <div className="font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {tile.label}
                </div>
              </Link>
            ))}
            <Link
              href="/industries"
              className="bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 transition-colors rounded-xl p-5 text-center"
            >
              <div className="text-2xl font-bold text-indigo-600">+183</div>
              <div className="text-xs text-indigo-700 mt-1 font-mono uppercase tracking-wide">More Industries</div>
              <div className="text-xs text-indigo-600 font-medium mt-2">See all →</div>
            </Link>
          </div>
        </div>
      </section>

      {/* ───────────────── HOW IT WORKS ───────────────── */}
      <section className="px-6 py-20">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12">
            <p className="text-xs font-mono text-indigo-600 mb-2">// HOW IT WORKS</p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight max-w-3xl">
              Live in the time it takes to make coffee.
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                num: "01",
                time: "~ 60 SECONDS",
                title: "Sign up",
                desc: "Email and a phone number. No procurement, no implementation team. Card optional during trial.",
              },
              {
                num: "02",
                time: "~ 4 MINUTES",
                title: "Tell us about your business",
                desc: "Pick your industry — we pre-load the playbook. Add hours, pricing, scheduling tool. Neverr writes the rest.",
              },
              {
                num: "03",
                time: "LIVE",
                title: "Your AI handles calls",
                desc: "Forward your number — or get a fresh one. Every call answered, transcribed, routed, and synced to your CRM.",
              },
            ].map((step, i) => (
              <div key={step.num} className="relative">
                <div className="flex items-center gap-3 mb-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-mono text-sm font-bold ${
                    i === 2 ? "bg-indigo-600 text-white" : "bg-white border border-slate-300 text-slate-700"
                  }`}>
                    {step.num}
                  </div>
                  <span className="text-xs font-mono text-slate-500 tracking-wider">{step.time}</span>
                </div>
                <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <EarlyAccessSection />

      {/* ───────────────── SAMPLE CALLS (replaces testimonials) ───────────────── */}
      <section className="px-6 py-20 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12">
            <p className="text-xs font-mono text-indigo-400 mb-2">// IN THE FIELD</p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight max-w-3xl">
              Calls answered. Jobs booked. Owners sleeping.
            </h2>
            <p className="text-slate-400 mt-3 max-w-xl">
              Real examples of how Neverr handles the calls your team can't always pick up.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-5">
            {SAMPLE_CALLS.map((call, i) => (
              <div key={i} className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
                <div className="text-xs font-mono text-indigo-400 uppercase tracking-wider mb-4">
                  {call.industry}
                </div>
                <div className="mb-4">
                  <div className="text-xs text-slate-500 mb-1">Caller</div>
                  <p className="text-sm text-slate-300 italic">{call.caller}</p>
                </div>
                <div>
                  <div className="text-xs text-slate-500 mb-1">Neverr</div>
                  <p className="text-sm text-slate-100 leading-relaxed">{call.response}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ───────────────── PRICING TEASER ───────────────── */}
      <section className="px-6 py-20 bg-white">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-xs font-mono text-indigo-600 mb-2">// PRICING</p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">
              One missed call usually pays for the month.
            </h2>
            <p className="text-slate-600 mb-2">
              Plans start at <strong className="text-slate-900">$149/mo</strong>. Most teams pick Professional. No annual lock-in. Cancel anytime from inside the dashboard.
            </p>
            <Link href="/pricing" className="inline-flex items-center gap-1 text-sm font-medium text-indigo-600 hover:text-indigo-700 mt-4">
              See all plans <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="bg-gradient-to-br from-indigo-50 to-violet-50 rounded-2xl p-8 border border-indigo-200 relative">
            <div className="absolute top-4 right-4 px-2 py-1 bg-slate-900 text-white text-[10px] font-mono uppercase tracking-wide rounded">
              Most Popular
            </div>

            <div className="text-xs font-mono text-slate-500 uppercase tracking-wider mb-2">Professional</div>
            <div className="flex items-baseline gap-2 mb-1">
              <span className="text-5xl font-bold">$749</span>
              <span className="text-slate-500 font-mono text-sm">/mo</span>
            </div>
            <div className="text-xs text-slate-500 mb-6">+ $499 setup · 2,500 minutes · 2,000 SMS</div>

            <ul className="space-y-2.5 mb-6">
              {[
                "Industry playbook (193+)",
                "All 32 languages",
                "Automated follow-up sequences",
                "Webhook + Zapier",
                "Email + chat support 24hr",
              ].map((f) => (
                <li key={f} className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                  <span className="text-slate-700">{f}</span>
                </li>
              ))}
            </ul>

            <Link
              href="/signup"
              className="block text-center w-full py-3 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800 transition-colors"
            >
              Start free trial →
            </Link>
            <p className="text-xs text-slate-500 text-center mt-3 font-mono">7-day free trial</p>
          </div>
        </div>
      </section>

      {/* ───────────────── FINAL CTA ───────────────── */}
      <section className="px-6 py-12 md:py-20">
        <div className="max-w-7xl mx-auto bg-gradient-to-br from-slate-900 to-slate-800 rounded-3xl p-12 md:p-16 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 via-transparent to-violet-500/10"></div>

          <div className="relative grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <p className="text-2xl md:text-3xl font-bold text-white/90 mb-8 tracking-tight">
                Never miss a call.{" "}
                <span className="text-white/60">Never miss a client.</span>{" "}
                <span className="bg-gradient-to-r from-indigo-300 to-violet-300 bg-clip-text text-transparent">Neverr.</span>
              </p>
              <p className="text-xs font-mono text-indigo-400 mb-3 tracking-wider">// 30 SECONDS</p>
              <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight leading-[1.1]">
                Try your AI receptionist before you finish this page.
              </h2>
              <p className="text-indigo-200 mt-3 text-sm font-mono">
                Now accepting first 100 businesses · 7-day free trial
              </p>
            </div>

            <div className="flex flex-col gap-3 lg:items-end">
              <Link
                href="/try-your-agent"
                className="inline-flex items-center justify-center gap-2 px-8 py-3 bg-indigo-500 text-white rounded-lg font-semibold hover:bg-indigo-600 transition-colors shadow-lg shadow-indigo-500/30 w-full lg:w-auto"
              >
                Try live demo <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/signup"
                className="inline-flex items-center justify-center gap-2 px-8 py-3 bg-white text-slate-900 rounded-lg font-semibold hover:bg-slate-100 transition-colors w-full lg:w-auto"
              >
                Start free trial
              </Link>
              <p className="text-xs text-slate-400 mt-1 font-mono lg:text-right">
                7-day free trial · cancel anytime
              </p>
            </div>
          </div>
        </div>
      </section>

      <NeverrVoiceWidget />
      <LandingFooter />
    </div>
  );
}
