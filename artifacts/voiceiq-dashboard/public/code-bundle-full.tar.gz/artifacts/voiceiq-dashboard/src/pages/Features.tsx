import { Link } from "wouter";
import { Briefcase, Clock, Sparkles, Check, ArrowRight } from "lucide-react";
import LandingNav from "../components/LandingNav";
import LandingFooter from "../components/LandingFooter";

const FEATURES = [
  {
    num: "01",
    icon: Briefcase,
    tag: "// PER-INDUSTRY CALIBRATION",
    title: "Industry-calibrated, not generic",
    paragraphs: [
      "Most voice AI is sold as one universal assistant. Neverr is the opposite — every deployment loads a playbook tuned to a specific industry. A plumber's receptionist sounds like a plumber's receptionist. A personal-injury firm's intake sounds like an intake specialist who has done it a thousand times. A dental front desk knows the difference between a hygiene cleaning and an emergency.",
      "We've built 193+ of these playbooks. Each one ships with the questions callers actually ask in that vertical, the qualifying flow that turns a call into a booking, and the disclaimers and transfer rules that make the conversation safe to hand off to a human.",
    ],
    bullets: [
      "193+ industry playbooks live, from HVAC and dental to legal intake and government services",
      "Pre-loaded qualifying questions, transfer rules, and disclaimers for each vertical",
      "Custom AI prompts on Starter and above for any business that needs to deviate from the template",
      "First call sounds like the hundredth — no months of training, no script-tuning sprints",
    ],
  },
  {
    num: "02",
    icon: Clock,
    tag: "// 24/7 ANSWERING",
    title: "Never misses a call",
    paragraphs: [
      "Every ring answered in under two seconds, every hour of every day. Overflow when your team is on the phone, after-hours when nobody's at the desk, the lunch hour, holidays, the weekend rush — Neverr is on. The result is a 100% answer rate against the 60-something-percent most teams hit on a good week.",
      "When a real human is needed, Neverr knows. It books a callback into your calendar, fires the relevant CRM update, and sends the caller a confirmation SMS so the lead doesn't go cold while you finish what you're doing.",
    ],
    bullets: [
      "Sub-two-second pickup, 24/7, no exceptions for holidays or weekends",
      "Live transfer rules for VIPs, emergencies, and anything you mark as human-only",
      "Automatic callback scheduling into Google Calendar or Outlook when a human is required",
      "Post-call SMS confirmations and daily owner briefings so nothing falls through the cracks",
    ],
  },
  {
    num: "03",
    icon: Sparkles,
    tag: "// TRY BEFORE YOU BUY",
    title: "Live demo, no signup",
    paragraphs: [
      "You can hear your own AI receptionist before you ever enter a credit card. Pick the industry that matches your business, hit dial, and have a real conversation with the agent that would answer your phones tomorrow. No mock data, no scripted demo — the same voice engine our paying customers use, calibrated to your vertical on the spot.",
      "If you want a deeper look at what a configured account does day-to-day, the demo dashboards mint a real session against a sandbox tenant so you can click through calls, transcripts, lead scores, and briefings before deciding to start a trial.",
    ],
    bullets: [
      "Call a working agent for any of 193+ industries from the demo page",
      "Walk through a fully populated dashboard — calls, transcripts, contacts, analytics — without signing up",
      "32 languages available on the same engine, so you can hear it answer in the language your customers speak",
      "When you're ready, a 7-day free trial starts with one click",
    ],
  },
];

export default function Features() {
  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      <LandingNav />

      {/* Hero */}
      <section className="px-6 py-16 md:py-24 bg-gradient-to-b from-white to-slate-50">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-xs font-mono text-indigo-600 mb-3">// FEATURES</p>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-slate-900 mb-5">
            Everything Neverr does, in one page.
          </h1>
          <p className="text-base md:text-lg text-slate-600 max-w-2xl mx-auto">
            A receptionist that actually knows your business — calibrated per industry, on every call, every hour. The deep dive on what's inside the product.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-8">
            <Link
              href="/signup"
              className="px-5 py-3 bg-slate-900 text-white rounded-lg text-sm font-semibold hover:bg-slate-800 transition-colors flex items-center gap-1.5"
            >
              Start your 7-day free trial <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/try-your-agent"
              className="px-5 py-3 border border-slate-300 text-slate-700 rounded-lg text-sm font-semibold hover:bg-slate-100 transition-colors"
            >
              Or try a live demo
            </Link>
          </div>
        </div>
      </section>

      {/* Feature deep-dives */}
      <section className="px-6 py-16 md:py-20">
        <div className="max-w-5xl mx-auto space-y-16 md:space-y-24">
          {FEATURES.map((feature) => {
            const Icon = feature.icon;
            return (
              <article
                key={feature.num}
                className="grid md:grid-cols-[auto_1fr] gap-6 md:gap-10"
              >
                <div className="flex md:flex-col items-start gap-4 md:gap-6">
                  <div className="w-12 h-12 md:w-14 md:h-14 bg-indigo-50 rounded-xl flex items-center justify-center shrink-0">
                    <Icon className="w-6 h-6 md:w-7 md:h-7 text-indigo-600" />
                  </div>
                  <span className="text-xs font-mono text-slate-400 self-center md:self-auto">{feature.num}</span>
                </div>

                <div className="min-w-0">
                  <p className="text-xs font-mono text-indigo-600 mb-2">{feature.tag}</p>
                  <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 mb-4">
                    {feature.title}
                  </h2>
                  <div className="space-y-4 text-slate-600 leading-relaxed text-[15px] md:text-base">
                    {feature.paragraphs.map((p, i) => (
                      <p key={i}>{p}</p>
                    ))}
                  </div>
                  <ul className="mt-6 space-y-3">
                    {feature.bullets.map((b, i) => (
                      <li key={i} className="flex items-start gap-3 text-[15px] text-slate-700">
                        <Check className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="px-6 py-16 md:py-20 bg-slate-900 text-white">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">
            Start your 7-day free trial
          </h2>
          <p className="text-slate-300 text-base md:text-lg mb-8 max-w-xl mx-auto">
            Card optional during the trial. Live in the time it takes to make coffee.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              href="/signup"
              className="px-6 py-3 bg-white text-slate-900 rounded-lg text-sm font-semibold hover:bg-slate-100 transition-colors flex items-center gap-1.5"
            >
              Get started free <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/pricing"
              className="px-6 py-3 border border-slate-700 text-slate-200 rounded-lg text-sm font-semibold hover:bg-slate-800 transition-colors"
            >
              See pricing
            </Link>
          </div>
        </div>
      </section>

      <LandingFooter />
    </div>
  );
}
