import { useState } from "react";
import { Link } from "wouter";
import { ArrowRight, Check, X } from "lucide-react";
import LandingNav from "../components/LandingNav";
import LandingFooter from "../components/LandingFooter";

const API = window.location.origin + "/api";

const SMB_PLANS = [
  {
    name: "Essential", price: 149, setup: 99, annual: 1350,
    minutes: "120 min", locations: "1 location", sms: "100 SMS/mo",
    features: ["All 193+ templates", "English + Spanish", "Google Calendar", "Lead scoring", "Post-call SMS", "Daily briefing", "Neverr Score", "HIPAA mode"],
    notIncluded: ["SMS campaigns", "Outlook Calendar", "Advanced analytics"],
    support: "Email only 72hr", popular: false, ctaStyle: "outline",
  },
  {
    name: "Starter", price: 349, setup: 199, annual: 3190,
    minutes: "750 min", locations: "1 location", sms: "500 SMS/mo",
    features: ["Everything in Essential", "Outlook Calendar", "500 SMS campaigns/month", "Full analytics + export", "Custom AI prompt", "HIPAA mode"],
    notIncluded: [],
    support: "Email 48hr", popular: false, ctaStyle: "outline",
  },
  {
    name: "Professional", price: 749, setup: 499, annual: 6850,
    minutes: "2,500 min", locations: "1 location", sms: "2,000 SMS/mo",
    features: ["Everything in Starter", "All 32 languages", "2,000 SMS campaigns/month", "Automated follow-up sequences", "Webhook + Zapier", "30-min onboarding call", "Email + chat support 24hr"],
    notIncluded: [],
    support: "Email + chat 24hr", popular: true, ctaStyle: "filled",
  },
  {
    name: "Growth", price: 999, setup: 799, annual: 9990, badge: "NEW",
    minutes: "4,000 min", locations: "2 locations", sms: "5,000 SMS/mo",
    features: ["Everything in Professional", "2 locations", "Two-way SMS", "5,000 SMS campaigns", "Custom reports", "Multi-location reporting", "Native CRM (HubSpot)", "Priority support 8hr", "45-min onboarding", "Quarterly strategy call"],
    notIncluded: [],
    support: "Priority 8hr", popular: false, ctaStyle: "outline",
  },
  {
    name: "Business", price: 1499, setup: 999, annual: 13750,
    minutes: "6,000 min", locations: "3 locations", sms: "10,000 SMS/mo",
    features: ["Everything in Growth", "3 locations", "10,000 SMS campaigns", "Unlimited sequences", "Advanced CRM integrations", "Limited API access", "Priority support 4hr", "60-min guided onboarding"],
    notIncluded: [],
    support: "Priority 4hr", popular: false, ctaStyle: "outline",
  },
  {
    name: "Enterprise", price: 3499, setup: 2499, annual: 32000,
    minutes: "15,000 min", locations: "4 locations", sms: "30,000 SMS/mo",
    features: ["Everything in Business", "4 locations", "Custom AI voice clone", "Full API access", "30,000 SMS campaigns", "Dedicated success manager", "1-hour SLA", "99.9% uptime SLA guarantee", "White-glove onboarding", "Monthly strategy sessions"],
    notIncluded: [],
    support: "Dedicated 1hr SLA", popular: false, ctaStyle: "filled-dark",
  },
];

const FRANCHISE_PLANS = [
  {
    name: "Franchise Starter", price: 4999, setup: 4999, annual: 45000,
    minutes: "20,000 min", locations: "5–10 locations", sms: "50,000 SMS/mo",
    features: ["All 32 languages", "Brand-standard AI pushed to all locations", "Centralized + per-location dashboard", "Full API access", "Dedicated success manager", "1-hour SLA", "Monthly strategy sessions"],
  },
  {
    name: "Franchise Pro", price: 6999, setup: 6999, annual: 64000,
    minutes: "60,000 min", locations: "11–20 locations", sms: "150,000 SMS/mo",
    features: ["Everything in Franchise Starter", "Full white-label your brand", "Custom AI voice per brand", "Dedicated account team (2 people)", "30-min SLA", "Weekly strategy sessions", "12-month minimum contract"],
  },
  {
    name: "Franchise Enterprise", price: 0, setup: 0, annual: 0,
    minutes: "Unlimited", locations: "21+ locations", sms: "Unlimited",
    features: ["Everything in Franchise Pro", "Fully dedicated infrastructure", "On-site implementation team", "Executive sponsorship", "Custom SLA with financial penalties", "PO accepted", "24–36 month contract"],
  },
];

const VOLUME_TIERS = [
  { name: "Volume Starter", price: "$7,499/mo", setup: "$7,499 setup", minutes: "40,000 min", locations: "Up to 3 locations", range: "10K–25K calls/mo" },
  { name: "Volume Pro", price: "$14,999/mo", setup: "$14,999 setup", minutes: "100,000 min", locations: "Up to 10 locations", range: "25K–75K calls/mo" },
  { name: "Volume Enterprise", price: "Custom", setup: "Custom", minutes: "Unlimited", locations: "Unlimited", range: "75K+ calls/mo" },
];

const OVERAGE_TABLE = [
  { plan: "Essential", mins: "120 min", minOver: "$0.15/min", sms: "100 SMS", smsOver: "$0.035/SMS" },
  { plan: "Starter", mins: "750 min", minOver: "$0.12/min", sms: "500 SMS", smsOver: "$0.035/SMS" },
  { plan: "Professional", mins: "2,500 min", minOver: "$0.10/min", sms: "2,000 SMS", smsOver: "$0.030/SMS" },
  { plan: "Growth", mins: "4,000 min", minOver: "$0.09/min", sms: "5,000 SMS", smsOver: "$0.025/SMS" },
  { plan: "Business", mins: "6,000 min", minOver: "$0.08/min", sms: "10,000 SMS", smsOver: "$0.020/SMS" },
  { plan: "Enterprise", mins: "15,000 min", minOver: "$0.06/min", sms: "30,000 SMS", smsOver: "$0.015/SMS" },
  { plan: "Franchise Starter", mins: "20,000 min", minOver: "$0.05/min", sms: "50,000 SMS", smsOver: "$0.012/SMS" },
  { plan: "Franchise Pro", mins: "60,000 min", minOver: "$0.04/min", sms: "150,000 SMS", smsOver: "$0.010/SMS" },
];

function PricingSection() {
  const [annual, setAnnual] = useState(false);
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);
  const fmt = (n: number) => n.toLocaleString("en-US");

  async function handleGetStarted(planId: string) {
    const billingCycle = annual ? "annual" : "monthly";
    const token = localStorage.getItem("neverr_token");

    // Not logged in — bounce to signup carrying intent forward
    if (!token) {
      window.location.href = `/signup?plan=${planId}&cycle=${billingCycle}`;
      return;
    }

    const businessId =
      localStorage.getItem("neverr_active_business_id") ||
      localStorage.getItem("neverr_business_id");
    const email = localStorage.getItem("neverr_email");

    if (!businessId || !email) {
      window.location.href = `/signup?plan=${planId}&cycle=${billingCycle}`;
      return;
    }

    setLoadingPlan(planId);
    try {
      const r = await fetch(`${API}/stripe/create-checkout-session`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ planId, billingCycle, businessId, email }),
      });
      const data = await r.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        alert(data.error || "Unable to start checkout. Please try again or contact support.");
        setLoadingPlan(null);
      }
    } catch {
      alert("Network error. Please check your connection and try again.");
      setLoadingPlan(null);
    }
  }

  return (
    <>
      <section className="py-20 px-6 bg-gray-50" id="pricing">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-6">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1B2537] mb-2">Pricing</h2>
            <p className="text-gray-500 text-lg mb-2">For businesses with 1–4 locations</p>
            <p className="text-sm text-gray-400">Get started today — no sales call required</p>
          </div>

          <div className="flex items-center justify-center gap-3 mb-12">
            <span className={`text-sm font-medium ${!annual ? "text-[#1B2537]" : "text-gray-400"}`}>Monthly</span>
            <button onClick={() => setAnnual(!annual)} className={`relative w-12 h-6 rounded-full transition-colors ${annual ? "bg-[#2E75B6]" : "bg-gray-300"}`}>
              <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${annual ? "translate-x-6" : "translate-x-0.5"}`} />
            </button>
            <span className={`text-sm font-medium ${annual ? "text-[#1B2537]" : "text-gray-400"}`}>Annual</span>
            {annual && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-semibold">1 month free</span>}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {SMB_PLANS.map(plan => {
              const displayPrice = annual ? Math.round(plan.annual / 12) : plan.price;
              return (
                <div key={plan.name} className={`relative bg-white rounded-2xl p-6 text-left border-2 transition-all flex flex-col ${plan.popular ? "border-[#2E75B6] shadow-xl shadow-[#2E75B6]/10 scale-[1.01]" : "border-gray-200 hover:border-gray-300"}`}>
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-[#2E75B6] text-white text-[10px] font-bold rounded-full uppercase tracking-wider">Most Popular</div>
                  )}
                  {"badge" in plan && plan.badge && (
                    <div className="absolute -top-3 right-4 px-2.5 py-0.5 bg-green-500 text-white text-[10px] font-bold rounded-full uppercase tracking-wider">{plan.badge}</div>
                  )}
                  <h3 className="text-lg font-bold text-[#1B2537] mb-1">{plan.name}</h3>
                  <div className="flex items-baseline gap-1 mb-1">
                    <span className="text-3xl font-extrabold text-[#1B2537]">${fmt(displayPrice)}</span>
                    <span className="text-sm text-gray-400">/mo</span>
                  </div>
                  <p className="text-xs text-gray-400 mb-4">
                    {annual ? `$${fmt(plan.annual)}/yr · Save $${fmt(plan.price * 12 - plan.annual)}` : `+ $${fmt(plan.setup)} setup`}
                  </p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-md font-medium">{plan.minutes}</span>
                    <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-md font-medium">{plan.locations}</span>
                    <span className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded-md font-medium">{plan.sms}</span>
                  </div>
                  <ul className="space-y-2 mb-4 flex-1">
                    {plan.features.map(f => (
                      <li key={f} className="flex items-start gap-2 text-sm text-gray-600">
                        <Check className="w-3.5 h-3.5 text-[#2E75B6] shrink-0 mt-0.5" />{f}
                      </li>
                    ))}
                    {plan.notIncluded.map(f => (
                      <li key={f} className="flex items-start gap-2 text-sm text-gray-400">
                        <X className="w-3.5 h-3.5 text-gray-300 shrink-0 mt-0.5" />{f}
                      </li>
                    ))}
                  </ul>
                  <p className="text-[11px] text-gray-400 mb-3">{plan.support}</p>
                  {(() => {
                    const planId = plan.name.toLowerCase();
                    const isLoading = loadingPlan === planId;
                    return (
                      <button
                        type="button"
                        onClick={() => handleGetStarted(planId)}
                        disabled={isLoading}
                        className={`block text-center w-full py-2.5 rounded-lg text-sm font-semibold transition-colors disabled:opacity-60 disabled:cursor-not-allowed ${
                          plan.ctaStyle === "filled" ? "bg-[#2E75B6] text-white hover:bg-[#2563a0]"
                          : plan.ctaStyle === "filled-dark" ? "bg-[#1B2537] text-white hover:bg-[#2a3a52]"
                          : "border-2 border-gray-200 text-gray-700 hover:border-[#2E75B6] hover:text-[#2E75B6]"
                        }`}
                      >
                        {isLoading ? "Loading…" : "Get Started"}
                      </button>
                    );
                  })()}
                </div>
              );
            })}
          </div>

          <div className="mt-12 bg-white border border-gray-200 rounded-2xl p-6 text-center">
            <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-gray-600">
              <span>🛡️ 30-day money-back guarantee</span>
              <span>📞 No contracts on monthly plans</span>
              <span>⚡ Go live in 48 hours</span>
              <span>🌐 English + Spanish on every plan</span>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-amber-50/50 border-t border-amber-200/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-amber-600 font-semibold text-sm uppercase tracking-wider mb-2">Franchise & Multi-Location</p>
            <h2 className="text-3xl md:text-4xl font-bold text-[#1B2537] mb-2">For franchise networks and multi-location brands</h2>
            <p className="text-gray-500 text-lg">5 to 20+ locations under one platform</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {FRANCHISE_PLANS.map(plan => (
              <div key={plan.name} className="bg-white rounded-2xl p-6 text-left border-2 border-amber-200 hover:border-amber-400 transition-all flex flex-col">
                <h3 className="text-lg font-bold text-[#1B2537] mb-1">{plan.name}</h3>
                <div className="flex items-baseline gap-1 mb-1">
                  {plan.price > 0 ? (
                    <>
                      <span className="text-3xl font-extrabold text-[#1B2537]">${fmt(annual ? Math.round(plan.annual / 12) : plan.price)}</span>
                      <span className="text-sm text-gray-400">/mo</span>
                    </>
                  ) : (
                    <span className="text-3xl font-extrabold text-[#1B2537]">Custom</span>
                  )}
                </div>
                <p className="text-xs text-gray-400 mb-4">
                  {plan.price > 0 ? (annual ? `$${fmt(plan.annual)}/yr` : `+ $${fmt(plan.setup)} setup`) : "Contact for pricing"}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <span className="text-xs bg-amber-50 text-amber-700 px-2 py-1 rounded-md font-medium">{plan.minutes}</span>
                  <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-md font-medium">{plan.locations}</span>
                  <span className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded-md font-medium">{plan.sms}</span>
                </div>
                <ul className="space-y-2 mb-6 flex-1">
                  {plan.features.map(f => (
                    <li key={f} className="flex items-start gap-2 text-sm text-gray-600">
                      <Check className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />{f}
                    </li>
                  ))}
                </ul>
                <Link href="/contact" className="block text-center w-full py-2.5 rounded-lg text-sm font-semibold bg-amber-500 text-white hover:bg-amber-600 transition-colors">Contact Sales</Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-[#1B2537]">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-4">
            <p className="text-[#2E75B6] font-semibold text-sm uppercase tracking-wider mb-2">High Volume & Government</p>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">For organizations handling 10,000+ calls per month</h2>
            <p className="text-gray-400 text-lg mb-2">DMV offices · Hospitals · Airlines · Utilities · Government agencies · Universities</p>
            <p className="text-xs text-gray-500 bg-white/5 inline-block px-4 py-1.5 rounded-full">10,000+ calls/month at a single entity</p>
          </div>
          <div className="space-y-4 mt-10">
            {VOLUME_TIERS.map(t => (
              <div key={t.name} className="bg-white/[0.06] border border-white/10 rounded-xl p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <h3 className="text-lg font-bold text-white">{t.name}</h3>
                  <p className="text-sm text-gray-400">{t.range}</p>
                </div>
                <div className="flex flex-wrap gap-4 text-sm">
                  <span className="text-white font-semibold">{t.price}</span>
                  <span className="text-gray-400">{t.setup}</span>
                  <span className="text-[#2E75B6]">{t.minutes}</span>
                  <span className="text-gray-400">{t.locations}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link href="/contact" className="inline-flex items-center gap-2 px-8 py-3 bg-[#2E75B6] text-white font-semibold rounded-xl hover:bg-[#2563a0] transition-colors">
              Contact Sales <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="py-16 px-6 bg-gray-50">
        <div className="max-w-5xl mx-auto">
          <h3 className="text-xl font-bold text-[#1B2537] mb-6 text-center">Overage Rates</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="border-b-2 border-gray-200">
                  <th className="text-left py-3 px-4 font-semibold text-[#1B2537]">Plan</th>
                  <th className="text-left py-3 px-4 font-semibold text-[#1B2537]">Included Minutes</th>
                  <th className="text-left py-3 px-4 font-semibold text-[#1B2537]">Minute Overage</th>
                  <th className="text-left py-3 px-4 font-semibold text-[#1B2537]">Included SMS</th>
                  <th className="text-left py-3 px-4 font-semibold text-[#1B2537]">SMS Overage</th>
                </tr>
              </thead>
              <tbody>
                {OVERAGE_TABLE.map((row, i) => (
                  <tr key={row.plan} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                    <td className="py-2.5 px-4 font-medium text-[#1B2537]">{row.plan}</td>
                    <td className="py-2.5 px-4 text-gray-600">{row.mins}</td>
                    <td className="py-2.5 px-4 text-gray-600">{row.minOver}</td>
                    <td className="py-2.5 px-4 text-gray-600">{row.sms}</td>
                    <td className="py-2.5 px-4 text-gray-600">{row.smsOver}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </>
  );
}

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-white">
      <LandingNav />
      <PricingSection />
      <LandingFooter />
    </div>
  );
}
