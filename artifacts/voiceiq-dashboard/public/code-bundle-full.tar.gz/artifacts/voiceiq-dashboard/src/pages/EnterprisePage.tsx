import { useState } from "react";
import { Link } from "wouter";
import { ArrowRight, ChevronDown } from "lucide-react";
import LandingNav from "../components/LandingNav";
import LandingFooter from "../components/LandingFooter";
import { getDiscoveryCallUrl } from "../lib/cta";

// 2026-05-03 Calendly swap: resolved from VITE_CALENDLY_URL at build
// time, falls back to /contact?topic=enterprise. Single getter call
// per render — see src/lib/cta.ts.
const CONTACT_HREF = getDiscoveryCallUrl();

const ENTERPRISE_FEATURES: Array<{
  emoji: string;
  title: string;
  body: string;
}> = [
  {
    emoji: "🏢",
    title: "Multi-location at scale",
    body: "Tested at 50+ business locations under one customer. Centralized billing, per-location voice agents, role-based access for your operations team.",
  },
  {
    emoji: "🔐",
    title: "Single sign-on (SAML 2.0)",
    body: "SAML SSO via WorkOS — works with Okta, Azure AD, Auth0, Google Workspace, OneLogin. Email-domain auto-routing for your team. JIT provisioning so onboarding takes seconds.",
  },
  {
    emoji: "🌐",
    title: "IP allowlisting",
    body: "Restrict dashboard access to your office, VPN, or specific IP ranges. CIDR notation supported. Configured per-tenant, enforced at the edge.",
  },
  {
    emoji: "📋",
    title: "Audit logs",
    body: "Every config change, login, agent edit, billing event — logged with actor, IP, user-agent, timestamp. Exportable. Cross-tenant access denied by default.",
  },
  {
    emoji: "⏰",
    title: "Configurable data retention",
    body: "Set retention windows per data type — call recordings, transcripts, conversation history. Automated retention cron runs every 6 hours, executes scheduled deletions, audits the result.",
  },
  {
    emoji: "📜",
    title: "Custom contracts",
    body: "Custom MSA, DPA, BAA available. We'll redline. Your legal team gets the terms they need.",
  },
];

const COMPLIANCE_LIVE: string[] = [
  "TLS 1.3 in transit (HSTS enforced)",
  "AES-256 at rest (Supabase + Twilio + ElevenLabs all certified)",
  "Multi-factor auth (TOTP) for all dashboard accounts",
  "SAML 2.0 enterprise SSO via WorkOS",
  "IP allowlisting (CIDR-supported)",
  "Audit logs with cross-tenant access controls",
  "Configurable data retention with automated execution",
  "PII handling controls (configurable per-business)",
];

const COMPLIANCE_ROADMAP: string[] = [
  "SOC 2 Type 1 — audit underway, targeting Q4 2026",
  "ISO 27001 — planned 2027",
  "HIPAA — BAAs available today; formal HIPAA Type 1 attestation planned 2027",
];

const ROLLOUT_STEPS: Array<{
  num: string;
  title: string;
  body: string;
}> = [
  {
    num: "01",
    title: "Discovery call (30 min)",
    body: "We learn your operation — locations, call volume, vertical, integration needs, compliance requirements. You learn whether Neverr is a fit.",
  },
  {
    num: "02",
    title: "Custom scoping & contract",
    body: "We scope the rollout — agent prompts per location, integrations, SSO setup, retention policy. Legal redlines your MSA/DPA/BAA. Pricing is custom, scoped per deployment. Typical 30-min discovery call gets you a number within 48 hours.",
  },
  {
    num: "03",
    title: "Implementation",
    body: "We work directly with your team through setup. Real humans, not self-serve. SSO configured in your first session. Your call agent goes live within 7-14 days of contract signing.",
  },
];

const ENTERPRISE_INDUSTRIES: Array<{
  emoji: string;
  title: string;
  body: string;
}> = [
  {
    emoji: "🏥",
    title: "Healthcare networks",
    body: "DSOs, multi-location dental, urgent care chains, mental & behavioral health groups. HIPAA-conscious pipeline, BAA available.",
  },
  {
    emoji: "🏛️",
    title: "Government & municipal",
    body: "Permits, 311, utilities, public health. Inclusive language for diverse callers, audit logs for FOIA, no-PII handling defaults.",
  },
  {
    emoji: "🍕",
    title: "Franchises (5–200 locations)",
    body: "Restaurant, fitness, beauty, service-based. Per-location agent customization, centralized billing, franchisor-level reporting.",
  },
  {
    emoji: "⚖️",
    title: "Legal services",
    body: "Multi-office practices, intake call qualification, conflict-checking integration hooks, attorney-client privilege framing.",
  },
  {
    emoji: "🔧",
    title: "Field services at scale",
    body: "HVAC, plumbing, electrical, pest — multi-location operators with after-hours overflow needs.",
  },
  {
    emoji: "🏢",
    title: "Professional services",
    body: "Multi-office consulting firms, accounting practices, real estate brokerages. Sophisticated routing, calendar integrations, ICP-aware qualification.",
  },
];

const INTEGRATIONS: Array<{ heading: string; items: string[] }> = [
  {
    heading: "Identity",
    items: [
      "SAML 2.0 SSO",
      "Okta",
      "Azure AD",
      "Auth0",
      "Google Workspace",
      "OneLogin",
    ],
  },
  {
    heading: "Telephony",
    items: [
      "Twilio (SOC 2, HITRUST)",
      "Number porting available",
      "Multi-line per location",
    ],
  },
  {
    heading: "CRM & calendar",
    items: [
      "HubSpot",
      "Salesforce (via webhook)",
      "Google Calendar",
      "Microsoft 365",
      "Calendly",
    ],
  },
];

const FAQS: Array<{ q: string; a: string }> = [
  {
    q: "Can we run a security review before signing?",
    a: "Yes. We'll provide a security questionnaire response, our SOC 2 readiness documentation (audit underway), our subprocessor list (Supabase, Twilio, ElevenLabs, Stripe, Resend, WorkOS), and answer any custom questionnaire your team needs.",
  },
  {
    q: "Do you sign custom MSAs?",
    a: "Yes. Our standard MSA is a starting point; we expect to redline.",
  },
  {
    q: "What's your data residency?",
    a: "Primary data lives in Supabase (US-East). Voice calls route through Twilio US data centers. Voice synthesis through ElevenLabs (US). For EU residency requirements, talk to us — we can scope EU data placement on the enterprise tier.",
  },
  {
    q: "Can you sign a BAA for healthcare?",
    a: "Yes. We have a BAA template and will redline as needed for your use case.",
  },
  {
    q: "How does pricing work for 50+ locations?",
    a: "Custom. Typical enterprise contracts price by location count + call volume. Discovery call gets you a real number within 48 hours.",
  },
  {
    q: "What happens to our data if we churn?",
    a: "Standard 30-day data export window. We can negotiate longer retention or faster deletion in your contract. Configurable retention also lets you set deletion windows during active service.",
  },
  {
    q: "Can we self-host?",
    a: "Not currently. Cloud-only. Roadmap: dedicated single-tenant deployments for customers requiring it (talk to us about needs and timeline).",
  },
];

function FaqItem({ q, a, defaultOpen }: { q: string; a: string; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(!!defaultOpen);
  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left hover:bg-slate-50 transition-colors"
      >
        <span className="text-base font-semibold text-slate-900">{q}</span>
        <ChevronDown
          className={`w-5 h-5 text-slate-400 flex-shrink-0 transition-transform ${
            open ? "rotate-180" : ""
          }`}
        />
      </button>
      {open && (
        <div className="px-5 pb-5 -mt-1 text-sm text-slate-600 leading-relaxed">
          {a}
        </div>
      )}
    </div>
  );
}

export default function EnterprisePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <LandingNav />

      {/* HERO */}
      <section className="px-6 pt-16 pb-12 md:pt-24 md:pb-16">
        <div className="max-w-5xl mx-auto text-center">
          <p className="text-xs font-mono text-indigo-600 mb-4 tracking-wider">
            // FOR FRANCHISES, MULTI-LOCATION OPERATORS, GOVERNMENT, AND HEALTHCARE NETWORKS
          </p>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-slate-900 mb-5 leading-tight">
            Built for the call your customer is about to make — at the scale your operation actually runs.
          </h1>
          <p className="text-base md:text-lg text-slate-600 max-w-3xl mx-auto">
            Neverr's enterprise tier handles 50+ locations under one customer, with the security
            controls, compliance posture, and contract flexibility your procurement team expects.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-8">
            <Link
              href={CONTACT_HREF}
              className="px-5 py-3 bg-slate-900 text-white rounded-lg text-sm font-semibold hover:bg-slate-800 transition-colors flex items-center gap-1.5"
            >
              Book a 30-min enterprise call <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/pricing"
              className="px-5 py-3 bg-white text-slate-700 border border-slate-300 rounded-lg text-sm font-semibold hover:bg-slate-50 transition-colors"
            >
              See SMB pricing
            </Link>
          </div>
        </div>
      </section>

      {/* TRUST STRIP — dark band */}
      <section className="bg-slate-900 text-slate-200 border-y border-slate-800">
        <div className="max-w-7xl mx-auto px-6 py-5">
          <p className="text-center text-[11px] md:text-xs font-mono tracking-wider uppercase text-slate-300 leading-relaxed">
            <span className="text-white font-semibold">50+ LOCATIONS</span>
            <span className="mx-2 text-slate-600">·</span>
            SAML SSO
            <span className="mx-2 text-slate-600">·</span>
            IP ALLOWLISTING
            <span className="mx-2 text-slate-600">·</span>
            AUDIT LOGS
            <span className="mx-2 text-slate-600">·</span>
            CONFIGURABLE RETENTION
            <span className="mx-2 text-slate-600">·</span>
            SOC 2 IN PROGRESS
            <span className="mx-2 text-slate-600">·</span>
            BAAs AVAILABLE
            <span className="mx-2 text-slate-600">·</span>
            CUSTOM CONTRACTS
          </p>
        </div>
      </section>

      {/* SECTION 2 — What enterprise gets */}
      <section className="px-6 py-16 md:py-20">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-10">
            What enterprise customers get that SMB plans don't
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {ENTERPRISE_FEATURES.map((f) => (
              <div
                key={f.title}
                className="bg-white rounded-xl border border-slate-200 p-6 hover:border-blue-400 hover:shadow-lg transition-all"
              >
                <div className="flex items-start gap-3 mb-3">
                  <span className="text-2xl flex-shrink-0" aria-hidden="true">
                    {f.emoji}
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 leading-tight">{f.title}</h3>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">{f.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 3 — Security & compliance */}
      <section className="px-6 py-16 md:py-20 bg-slate-50/60 border-y border-slate-200/70">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-10">
            Security &amp; compliance
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <h3 className="text-sm font-mono text-emerald-700 uppercase tracking-wider mb-4">
                What's live today
              </h3>
              <ul className="space-y-2.5">
                {COMPLIANCE_LIVE.map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-sm text-slate-700">
                    <span className="text-emerald-600 font-bold mt-0.5 flex-shrink-0" aria-hidden="true">
                      ✓
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <h3 className="text-sm font-mono text-amber-700 uppercase tracking-wider mb-4">
                On the path
              </h3>
              <ul className="space-y-2.5">
                {COMPLIANCE_ROADMAP.map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-sm text-slate-700">
                    <span className="text-amber-600 mt-0.5 flex-shrink-0" aria-hidden="true">
                      ⏳
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <p className="mt-6 text-sm text-slate-600 max-w-3xl mx-auto text-center leading-relaxed">
            For healthcare customers: BAA available on request. Our agent pipeline is designed to
            minimize PHI handling — calls escalate to staff per your protocol rather than storing
            protected health information server-side.
          </p>
        </div>
      </section>

      {/* SECTION 4 — How rollouts work */}
      <section className="px-6 py-16 md:py-20">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-10">
            How enterprise rollouts work with us
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {ROLLOUT_STEPS.map((s) => (
              <div
                key={s.num}
                className="bg-white rounded-xl border border-slate-200 p-6 hover:border-blue-400 hover:shadow-lg transition-all"
              >
                <div className="text-xs font-mono text-indigo-600 mb-3 tracking-wider">
                  // STEP {s.num}
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{s.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{s.body}</p>
              </div>
            ))}
          </div>
          <p className="mt-8 text-center text-sm text-slate-600 max-w-3xl mx-auto">
            Every enterprise customer gets a real human on our side from discovery through implementation.
          </p>
        </div>
      </section>

      {/* SECTION 5 — Industries we serve at enterprise scale */}
      <section className="px-6 py-16 md:py-20 bg-slate-50/60 border-y border-slate-200/70">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-10">
            Built for the verticals where call coverage actually matters
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {ENTERPRISE_INDUSTRIES.map((i) => (
              <div
                key={i.title}
                className="bg-white rounded-xl border border-slate-200 p-6 hover:border-blue-400 hover:shadow-lg transition-all"
              >
                <div className="flex items-start gap-3 mb-3">
                  <span className="text-2xl flex-shrink-0" aria-hidden="true">
                    {i.emoji}
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 leading-tight">{i.title}</h3>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">{i.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 6 — Architecture & integration */}
      <section className="px-6 py-16 md:py-20">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-10">
            Built to integrate with your stack
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {INTEGRATIONS.map((col) => (
              <div
                key={col.heading}
                className="bg-white rounded-xl border border-slate-200 p-6"
              >
                <h3 className="text-sm font-mono text-indigo-600 uppercase tracking-wider mb-4">
                  {col.heading}
                </h3>
                <ul className="space-y-2">
                  {col.items.map((it) => (
                    <li key={it} className="text-sm text-slate-700">
                      {it}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <p className="mt-6 text-center text-sm text-slate-600 max-w-3xl mx-auto">
            Custom integrations on the enterprise tier. If your stack isn't on this list, we'll scope it.
          </p>
        </div>
      </section>

      {/* SECTION 7 — FAQ */}
      <section className="px-6 py-16 md:py-20 bg-slate-50/60 border-y border-slate-200/70">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-10">
            Procurement questions, answered
          </h2>
          <div className="space-y-3">
            {FAQS.map((f, idx) => (
              <FaqItem key={f.q} q={f.q} a={f.a} defaultOpen={idx === 0} />
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 8 — Final CTA (gradient card matching IndustriesHub pattern) */}
      <section className="px-6 py-16 md:py-20">
        <div className="max-w-7xl mx-auto">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 md:p-12 text-center text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-3">Ready to talk?</h2>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              Enterprise pricing is custom. Discovery call gets you a number within 48 hours.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link
                href={CONTACT_HREF}
                className="inline-flex items-center gap-2 px-6 py-3 bg-white text-blue-700 rounded-lg font-semibold hover:bg-blue-50 transition-colors shadow-md"
              >
                Book a 30-min discovery call <ArrowRight className="w-4 h-4" />
              </Link>
              <a
                href="mailto:enterprise@neverr.ai"
                className="inline-flex items-center gap-2 px-6 py-3 bg-blue-700/30 text-white border border-blue-300/40 rounded-lg font-semibold hover:bg-blue-700/50 transition-colors"
              >
                Email enterprise@neverr.ai
              </a>
            </div>
            <p className="mt-6 text-sm text-blue-100/90">
              Already a customer and looking to upgrade? Login → Settings → Billing, or email us.
            </p>
          </div>
        </div>
      </section>

      <LandingFooter />
    </div>
  );
}
