// 2026-05-03 Calendly env-var swap (frontend half).
//
// SINGLE source of truth for the discovery-call CTA URL on the
// marketing site. Every page/component that needs to send the user to
// "book a discovery call" imports this — never hard-code the path
// again. If you find yourself typing "/contact?topic=enterprise" in
// JSX, stop and import this helper instead.
//
// Resolution order:
//   1. import.meta.env.VITE_CALENDLY_URL (build-time, Vite env). If
//      set and starts with https://, use it.
//   2. Fallback: /contact?topic=enterprise (the existing generic
//      contact form, scoped to topic=enterprise so the form router
//      knows it's a sales-side intent).
//
// Build-time vs runtime:
//   Vite bakes import.meta.env values into the bundle at build time,
//   so changing VITE_CALENDLY_URL requires a dashboard rebuild — see
//   replit.md for the deploy steps. The api-server side
//   (NEVERR_CALENDLY_URL → Alex chat) is also restart-gated on Replit
//   (Replit Secrets do NOT hot-reload into running processes), but
//   once the api-server workflow is restarted every new conversation
//   immediately sees the live URL — no module-init snapshot, no code
//   edits. If we ever need the dashboard pages to swap without a
//   rebuild, swap this helper to fetch /api/config on app boot and
//   stash the result in a context.
const FALLBACK_URL = "/contact?topic=enterprise";

export function getDiscoveryCallUrl(): string {
  const env = (import.meta.env.VITE_CALENDLY_URL as string | undefined) ?? "";
  if (env && env.startsWith("https://")) return env;
  return FALLBACK_URL;
}
