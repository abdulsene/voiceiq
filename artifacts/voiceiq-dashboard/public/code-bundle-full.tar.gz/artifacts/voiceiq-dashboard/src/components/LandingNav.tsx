import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "./ui/sheet";

const NAV_LINKS: Array<{ href: string; label: string }> = [
  { href: "/features", label: "Features" },
  { href: "/industries", label: "Industries" },
  { href: "/pricing", label: "Pricing" },
  { href: "/enterprise", label: "Enterprise" },
];

export default function LandingNav() {
  const [mobileOpen, setMobileOpen] = useState(false);

  const [isShrunk, setIsShrunk] = useState(false);

  useEffect(() => {
    const sentinel = document.querySelector("[data-hero-sentinel]");
    if (!sentinel) {
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsShrunk(!entry.isIntersecting);
      },
      { rootMargin: "-80px 0px 0px 0px", threshold: 0 },
    );
    observer.observe(sentinel);
    return () => observer.disconnect();
  }, []);

  return (
    <header
      className={`sticky top-0 z-40 bg-white/80 border-b border-slate-200/60 transition-all duration-200 ease-out ${
        isShrunk ? "backdrop-blur-lg shadow-sm" : "backdrop-blur-md"
      }`}
    >
      <div
        className={`max-w-7xl mx-auto px-6 flex items-center justify-between transition-all duration-200 ease-out ${
          isShrunk ? "py-3" : "py-5"
        }`}
      >
        <Link href="/" className="flex items-center gap-2">
          <img
            src={`${import.meta.env.BASE_URL}neverr-logo.png`}
            alt="Neverr — AI Receptionist"
            className={`w-auto transition-all duration-200 ease-out ${
              isShrunk ? "h-9 md:h-10" : "h-9 md:h-16"
            }`}
          />
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <nav className="flex items-center gap-6 text-sm text-slate-600">
            {NAV_LINKS.map((l) => (
              <Link key={l.href} href={l.href} className="hover:text-slate-900">
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <Link
              href="/login"
              className="text-sm text-slate-600 hover:text-slate-900"
            >
              Login
            </Link>
            <Link
              href="/signup"
              className="px-4 py-2 bg-slate-900 text-white rounded-lg text-sm font-semibold hover:bg-slate-800 transition-colors flex items-center gap-1.5"
            >
              Get started <span className="text-xs">→</span>
            </Link>
          </div>
        </div>

        <div className="md:hidden">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <button
                type="button"
                aria-label="Open menu"
                className="p-2 -mr-2 text-slate-700 hover:text-slate-900"
              >
                <Menu className="h-6 w-6" />
              </button>
            </SheetTrigger>
            <SheetContent
              side="right"
              className="w-[280px] sm:w-[320px] bg-white"
            >
              <nav className="flex flex-col gap-1 mt-8">
                {NAV_LINKS.map((l) => (
                  <Link
                    key={l.href}
                    href={l.href}
                    onClick={() => setMobileOpen(false)}
                    className="px-4 py-3 text-base text-slate-700 hover:bg-slate-50 rounded"
                  >
                    {l.label}
                  </Link>
                ))}
                <div className="border-t border-slate-200 my-4" />
                <a
                  href="tel:+19789638377"
                  onClick={() => setMobileOpen(false)}
                  className="px-4 py-3 text-base text-slate-700 hover:bg-slate-50 rounded flex items-center gap-2"
                >
                  <span>📞</span>
                  <span>(978) 9NEVERR</span>
                </a>
                <Link
                  href="/login"
                  onClick={() => setMobileOpen(false)}
                  className="px-4 py-3 text-base text-slate-700 hover:bg-slate-50 rounded"
                >
                  Login
                </Link>
                <Link
                  href="/signup"
                  onClick={() => setMobileOpen(false)}
                  className="px-4 py-3 mx-2 text-base text-center font-semibold bg-slate-900 text-white rounded hover:bg-slate-800"
                >
                  Get started →
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
