import { Link } from "wouter";
import { useState, type FormEvent } from "react";
import { ArrowRight } from "lucide-react";

const API = window.location.origin + "/api";

function FooterEmailSignup() {
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e?: FormEvent) {
    e?.preventDefault();
    setError(null);
    if (!email.trim() || !email.includes("@")) {
      setError("Valid email required");
      return;
    }
    setSubmitting(true);
    try {
      const r = await fetch(`${API}/marketing/subscribe`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: email.trim(),
          consent_transactional: false,
          consent_marketing: false,
          source: "footer_widget",
          page_url: window.location.href,
        }),
      });
      const d = await r.json();
      if (!r.ok) {
        setError(d.error || "Failed");
      } else {
        setSubmitted(true);
        setEmail("");
      }
    } catch (e: any) {
      setError(e.message);
    }
    setSubmitting(false);
  }

  if (submitted) {
    return (
      <div className="text-sm text-emerald-700 font-medium">
        ✓ Thanks! You're on the list.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2 max-w-md w-full">
      <input
        type="email"
        placeholder="Email for product updates"
        className="flex-1 p-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        disabled={submitting}
      />
      <button
        type="submit"
        disabled={submitting || !email.trim()}
        className="px-4 py-2 bg-slate-900 text-white rounded-lg text-sm font-semibold hover:bg-slate-800 transition-colors disabled:opacity-50 flex items-center justify-center gap-1.5"
      >
        {submitting ? "..." : <>Join <ArrowRight className="w-3.5 h-3.5" /></>}
      </button>
      {error && <p className="text-xs text-red-600 mt-1 sm:absolute">{error}</p>}
    </form>
  );
}

export default function LandingFooter() {
  return (
    <footer className="bg-slate-50 border-t border-slate-200">
      <div className="border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h3 className="font-semibold text-slate-900 mb-1">Join the early access list</h3>
            <p className="text-sm text-slate-600">Product updates, launch invites, early-access pricing.</p>
          </div>
          <FooterEmailSignup />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12 grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
        <div>
          <h3 className="font-semibold text-slate-900 mb-3">Product</h3>
          <ul className="space-y-2 text-slate-600">
            <li><Link href="/try-your-agent" className="hover:text-slate-900">Try a demo</Link></li>
            <li><Link href="/industries" className="hover:text-slate-900">Industries</Link></li>
            <li><Link href="/pricing" className="hover:text-slate-900">Pricing</Link></li>
            <li><Link href="/roi" className="hover:text-slate-900">ROI calculator</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="font-semibold text-slate-900 mb-3">Company</h3>
          <ul className="space-y-2 text-slate-600">
            <li><Link href="/enterprise" className="hover:text-slate-900">Enterprise</Link></li>
            <li><Link href="/contact" className="hover:text-slate-900">Contact sales</Link></li>
            <li><a href="mailto:hello@neverr.ai" className="hover:text-slate-900">Email us</a></li>
            <li><Link href="/partners" className="hover:text-slate-900">Partners</Link></li>
            <li>
              <a href="tel:+19789638377" className="hover:text-slate-900">
                +1 (978) 9NEVERR
              </a>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="font-semibold text-slate-900 mb-3">Account</h3>
          <ul className="space-y-2 text-slate-600">
            <li><Link href="/login" className="hover:text-slate-900">Sign in</Link></li>
            <li><Link href="/signup" className="hover:text-slate-900">Get started free</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="font-semibold text-slate-900 mb-3">Legal</h3>
          <ul className="space-y-2 text-slate-600">
            <li><Link href="/privacy" className="hover:text-slate-900">Privacy</Link></li>
            <li><Link href="/terms" className="hover:text-slate-900">Terms</Link></li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 mt-2 pb-8 pt-6 border-t border-slate-200 flex flex-col md:flex-row md:items-center md:justify-between gap-2 text-xs text-slate-500">
        <div>© {new Date().getFullYear()} Neverr AI · Never miss a call. Never miss a client. Never miss another dollar.</div>
        <div className="font-mono">v4.2 · 193+ industry playbooks live</div>
      </div>
    </footer>
  );
}
